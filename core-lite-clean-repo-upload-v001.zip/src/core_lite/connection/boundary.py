from __future__ import annotations

from core_lite.utils import read_json


def connection_check(export_manifest_path: str) -> dict:
    manifest = read_json(export_manifest_path)
    if manifest.get("decision") != "ALLOW":
        return {"decision": "FAIL_CLOSED", "reasons": ["Export manifest is not allowed."]}
    if manifest.get("tvc", {}).get("decision") != "ALLOW":
        return {"decision": "FAIL_CLOSED", "reasons": ["TVC validation missing."]}
    if not manifest.get("receipt_verification", {}).get("valid"):
        return {"decision": "FAIL_CLOSED", "reasons": ["Receipt verification missing."]}
    return {"decision": "ALLOW", "reasons": ["Connection boundary dry-run passed."]}
