from __future__ import annotations

from .response import normalize_llm_response


SENSITIVE_DOMAINS = {"legal", "medical", "financial", "security"}


def llm_gate(value: dict) -> dict:
    normalized = normalize_llm_response(value)
    metadata = normalized.get("metadata", {})
    domain = str(metadata.get("domain", "")).lower()

    if domain in SENSITIVE_DOMAINS:
        return {
            "decision": "SANDBOX",
            "reasons": [f"Sensitive domain detected: {domain}", "User confirmation required before continuation."],
            "llm": normalized,
        }

    if not normalized.get("response"):
        return {"decision": "FAIL_CLOSED", "reasons": ["Missing LLM response."], "llm": normalized}

    return {"decision": "ALLOW", "reasons": ["LLM output passed local gate."], "llm": normalized}
