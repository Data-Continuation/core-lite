from __future__ import annotations

from core_lite.utils import canonical_json, sha256_text


def normalize_llm_request(value: dict) -> dict:
    prompt = value.get("prompt") or value.get("request")
    if not prompt:
        return {"decision": "FAIL_CLOSED", "reasons": ["Missing prompt/request."]}
    result = {
        "provider": value.get("provider", "stub"),
        "model_ref": value.get("model_ref", "stub:deterministic:v1"),
        "prompt": str(prompt),
        "metadata": value.get("metadata", {}),
    }
    result["prompt_hash"] = sha256_text(canonical_json(result))
    result["decision"] = "ALLOW"
    return result
