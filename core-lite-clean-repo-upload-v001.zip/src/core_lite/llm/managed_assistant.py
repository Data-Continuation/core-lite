from __future__ import annotations

from .stub_provider import stub_complete
from .gate import llm_gate


def assistant_preview(value: dict) -> dict:
    completion = stub_complete(value)
    gate = llm_gate(completion)
    return {
        "decision": gate["decision"],
        "mode": "StegVerse Personal AI Assistant Preview",
        "comparison": {
            "unmanaged": "Unmanaged LLM returns an answer without continuation boundary checks.",
            "managed": "Managed assistant states assumptions, checks authority, and gates continuation.",
        },
        "assistant_output": completion,
        "gate": gate,
    }
