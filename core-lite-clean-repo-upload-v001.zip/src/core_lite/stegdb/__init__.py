from .local import put_record, get_record
