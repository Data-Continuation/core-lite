from __future__ import annotations

from core_lite.utils import canonical_json, sha256_text


def canonical_record(value: dict) -> dict:
    record_hash = sha256_text(canonical_json(value))
    return {"record_hash": record_hash, "record": value}
