from __future__ import annotations

from pathlib import Path

from core_lite.utils import read_json, write_json
from .record import canonical_record


def put_record(value: dict, out_dir: str | Path) -> dict:
    out = Path(out_dir) / "stegdb"
    out.mkdir(parents=True, exist_ok=True)
    wrapped = canonical_record(value)
    write_json(out / f"{wrapped['record_hash']}.json", wrapped)
    return wrapped


def get_record(record_hash: str, out_dir: str | Path) -> dict:
    path = Path(out_dir) / "stegdb" / f"{record_hash}.json"
    if not path.exists():
        return {"decision": "FAIL_CLOSED", "record_hash": record_hash, "reasons": ["Record not found."]}
    data = read_json(path)
    data["decision"] = "ALLOW"
    return data
