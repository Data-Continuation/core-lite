from __future__ import annotations

from core_lite.utils import now_utc


def export_manifest(source_dir: str, receipt_verification: dict, tvc_result: dict) -> dict:
    decision = "ALLOW" if receipt_verification.get("valid") and tvc_result.get("decision") == "ALLOW" else "FAIL_CLOSED"
    return {
        "export_version": "core-lite.export.v1",
        "created_utc": now_utc(),
        "source_dir": source_dir,
        "decision": decision,
        "receipt_verification": receipt_verification,
        "tvc": tvc_result,
    }
