from core_lite.capabilities import capability_manifest

def product_manifest() -> dict:
    return {"product": "core-lite", "version": "v001", **capability_manifest()}
