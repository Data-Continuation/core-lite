from __future__ import annotations

from .validator import validate_tvc


def require_boundary(value: dict) -> dict:
    result = validate_tvc(value)
    if result["decision"] != "ALLOW":
        return result
    return {"decision": "ALLOW", "reasons": ["TVC boundary passed."], "refs": result["refs"]}
