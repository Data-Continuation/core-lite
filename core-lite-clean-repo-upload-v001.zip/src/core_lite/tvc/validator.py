from __future__ import annotations

from typing import Any

from .refs import RAW_SECRET_KEYS, REQUIRED_REFS


def _contains_raw_secret(value: Any) -> bool:
    if isinstance(value, dict):
        for key, nested in value.items():
            if key.lower() in RAW_SECRET_KEYS:
                return True
            if _contains_raw_secret(nested):
                return True
    elif isinstance(value, list):
        return any(_contains_raw_secret(item) for item in value)
    return False


def validate_tvc(value: dict[str, Any]) -> dict:
    if _contains_raw_secret(value):
        return {"decision": "DENY", "reasons": ["Raw secret value detected."], "refs": {}}

    metadata = value.get("metadata", value)
    if not isinstance(metadata, dict):
        return {"decision": "FAIL_CLOSED", "reasons": ["TVC metadata must be an object."], "refs": {}}

    missing = [key for key in REQUIRED_REFS if not metadata.get(key)]
    if missing:
        return {"decision": "FAIL_CLOSED", "reasons": [f"Missing required TVC refs: {', '.join(missing)}"], "refs": metadata}

    refs = {key: metadata.get(key) for key in ("authority_ref", "policy_ref", "token_ref", "secret_ref") if metadata.get(key)}
    return {"decision": "ALLOW", "reasons": ["TVC refs validated."], "refs": refs}
