REQUIRED_REFS = ("authority_ref", "policy_ref")
RAW_SECRET_KEYS = ("secret", "api_key", "password", "private_key")
