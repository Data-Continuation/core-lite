from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CGEPolicy:
    sandbox_risk_threshold: float = 0.45
    deny_risk_threshold: float = 0.80
    denied_actions: tuple[str, ...] = ("delete_all", "exfiltrate", "disable_governance")
    sandbox_actions: tuple[str, ...] = ("external_call", "state_mutation", "unknown")
