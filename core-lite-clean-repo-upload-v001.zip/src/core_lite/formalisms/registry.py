from .data_continuation import evaluate_data_continuation

FORMALISMS = {
    "data-continuation.v1": evaluate_data_continuation,
}


def get_formalism(formalism_id: str = "data-continuation.v1"):
    return FORMALISMS[formalism_id]
