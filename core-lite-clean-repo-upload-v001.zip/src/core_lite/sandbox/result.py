def sandbox_result(decision: str, reasons: list[str], risk_score: float) -> dict:
    return {"decision": decision, "reasons": reasons, "risk_score": risk_score}
