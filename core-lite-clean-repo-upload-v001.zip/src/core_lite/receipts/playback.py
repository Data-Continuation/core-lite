from __future__ import annotations

import json
from pathlib import Path


def playback_receipts(path: str | Path) -> dict:
    receipt_path = Path(path)
    events = []
    if not receipt_path.exists():
        return {"decision": "FAIL_CLOSED", "timeline": [], "reasons": ["Receipt file missing."]}

    for index, line in enumerate(receipt_path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        receipt = json.loads(line)
        events.append({
            "step": index,
            "event_type": receipt.get("event_type"),
            "decision": receipt.get("decision"),
            "subject_hash": receipt.get("subject_hash"),
            "receipt_hash": receipt.get("receipt_hash"),
        })

    return {"decision": "ALLOW", "timeline": events, "reasons": ["Playback generated."]}
