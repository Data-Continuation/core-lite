from __future__ import annotations

import json
from pathlib import Path

from .chain import receipt_hash


def verify_receipts(path: str | Path) -> dict:
    receipt_path = Path(path)
    if not receipt_path.exists():
        return {"decision": "FAIL_CLOSED", "valid": False, "reasons": ["Receipt file missing."]}

    previous = None
    count = 0
    for line in receipt_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        receipt = json.loads(line)
        expected_previous = receipt.get("previous_receipt_hash")
        if expected_previous != previous:
            return {"decision": "FAIL_CLOSED", "valid": False, "reasons": ["Receipt previous hash mismatch."], "count": count}

        stored_hash = receipt.get("receipt_hash")
        body = dict(receipt)
        body.pop("receipt_hash", None)
        if receipt_hash(body) != stored_hash:
            return {"decision": "FAIL_CLOSED", "valid": False, "reasons": ["Receipt hash mismatch."], "count": count}

        previous = stored_hash
        count += 1

    return {"decision": "ALLOW", "valid": True, "reasons": ["Receipt chain verified."], "count": count}
