def object_ref(object_hash: str, path: str) -> dict:
    return {"object_hash": object_hash, "path": path}
