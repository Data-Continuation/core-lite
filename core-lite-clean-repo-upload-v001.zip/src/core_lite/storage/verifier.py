from __future__ import annotations

from pathlib import Path

from core_lite.utils import read_json, sha256_bytes


def verify_object_ref(ref_path: str | Path) -> dict:
    ref = read_json(ref_path)
    path = Path(ref.get("path", ""))
    if not path.exists():
        return {"decision": "FAIL_CLOSED", "valid": False, "reasons": ["Stored artifact missing."]}

    actual = sha256_bytes(path.read_bytes())
    valid = actual == ref.get("object_hash")
    return {
        "decision": "ALLOW" if valid else "FAIL_CLOSED",
        "valid": valid,
        "reasons": ["Object ref verified." if valid else "Object hash mismatch."],
    }
