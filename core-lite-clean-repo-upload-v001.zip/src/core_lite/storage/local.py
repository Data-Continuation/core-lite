from __future__ import annotations

import shutil
from pathlib import Path

from core_lite.utils import sha256_bytes, write_json
from .object_ref import object_ref


def put_artifact(path: str | Path, out_dir: str | Path) -> dict:
    source = Path(path)
    if not source.exists():
        return {"decision": "FAIL_CLOSED", "reasons": ["Artifact path missing."]}

    data = source.read_bytes()
    object_hash = sha256_bytes(data)
    store = Path(out_dir) / "storage"
    store.mkdir(parents=True, exist_ok=True)
    artifact_path = store / f"{object_hash}{source.suffix}"
    shutil.copyfile(source, artifact_path)

    ref = object_ref(object_hash, str(artifact_path))
    ref["decision"] = "ALLOW"
    write_json(store / f"{object_hash}.object_ref.json", ref)
    return ref
