from __future__ import annotations

from typing import Any

from core_lite.utils import canonical_json, sha256_text
from .envelope import IngestionEnvelope


def normalize_input(data: dict[str, Any]) -> IngestionEnvelope:
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object.")

    source = str(data.get("source", "unknown"))
    payload = data.get("payload", data)
    metadata = data.get("metadata", {})

    if not isinstance(payload, dict):
        raise ValueError("Payload must be an object.")
    if not isinstance(metadata, dict):
        raise ValueError("Metadata must be an object.")

    input_hash = sha256_text(canonical_json({
        "source": source,
        "payload": payload,
        "metadata": metadata,
    }))

    return IngestionEnvelope(source=source, payload=payload, metadata=metadata, input_hash=input_hash)
