from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class IngestionEnvelope:
    source: str
    payload: dict[str, Any]
    metadata: dict[str, Any]
    input_hash: str

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "payload": self.payload,
            "metadata": self.metadata,
            "input_hash": self.input_hash,
        }
