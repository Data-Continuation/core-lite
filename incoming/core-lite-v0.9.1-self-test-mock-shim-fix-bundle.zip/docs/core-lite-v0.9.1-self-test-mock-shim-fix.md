# Core-Lite v0.9.1: Self-Test Mock Shim Fix

## Purpose

Fix the Core-Lite self-test so the mock target repo is seeded with the required Core-Lite shims before `core_lite/cli.py run` executes.

## Failure addressed

The self-test failed because the mock repo reported:

```text
drift_flags: ["missing_shim"]
ingest_success: false
local_chain_valid: true
parent_links_valid_locally: true
```

That means chain validation was fine, but the mock repo was not a valid Core-Lite target because required shim files were absent.

## Fix

The self-test now creates these mock-target files before running Core-Lite:

```text
incoming/.gitkeep
.stegverse/core-lite.json
.github/workflows/core-lite-intake.yml
```

Displayed without leading dots:

```text
incoming/gitkeep
stegverse/core-lite.json
github/workflows/core-lite-intake.yml
```
