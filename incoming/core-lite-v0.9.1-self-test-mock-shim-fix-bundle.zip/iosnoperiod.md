# iosnoperiod

`iosnoperiod/` is an iOS-safe mirror of bundle files whose real repository paths contain leading periods.

Mapping rule:

```text
iosnoperiod/ = repository root
```

Examples:

```text
iosnoperiod/github/workflows/core-lite-self-test.yml -> .github/workflows/core-lite-self-test.yml
iosnoperiod/stegverse/ingest_manifest.json -> .stegverse/ingest_manifest.json
```

If a bundle appears to contain only `iosnoperiod.md` and `iosnoperiod/` on iOS, do not assume the bundle is invalid.
